import mysql from "mysql2/promise";
import dotenv from "dotenv";

dotenv.config();

const connection = await mysql.createConnection(process.env.DATABASE_URL);

// Insert default departments
const departments = [
  { name: "Technical Support", description: "Hardware and software issues", icon: "🔧", color: "#3b82f6" },
  { name: "Billing", description: "Payment and subscription issues", icon: "💳", color: "#10b981" },
  { name: "General Inquiry", description: "General questions and information", icon: "❓", color: "#f59e0b" },
  { name: "Bug Report", description: "Software bugs and defects", icon: "🐛", color: "#ef4444" },
  { name: "Feature Request", description: "New feature suggestions", icon: "✨", color: "#8b5cf6" },
];

console.log("Seeding database...");

for (const dept of departments) {
  try {
    await connection.execute(
      "INSERT INTO departments (name, description, icon, color) VALUES (?, ?, ?, ?) ON DUPLICATE KEY UPDATE description=?, icon=?, color=?",
      [dept.name, dept.description, dept.icon, dept.color, dept.description, dept.icon, dept.color]
    );
    console.log(`✓ Created department: ${dept.name}`);
  } catch (error) {
    console.error(`✗ Error creating department ${dept.name}:`, error.message);
  }
}

console.log("✓ Database seeding complete!");
await connection.end();
