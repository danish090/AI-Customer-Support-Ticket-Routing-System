import { int, mysqlEnum, mysqlTable, text, timestamp, varchar, decimal, boolean, json } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/**
 * Departments table for ticket routing
 */
export const departments = mysqlTable("departments", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 100 }).notNull().unique(),
  description: text("description"),
  icon: varchar("icon", { length: 50 }),
  color: varchar("color", { length: 20 }).default("#3b82f6"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Department = typeof departments.$inferSelect;
export type InsertDepartment = typeof departments.$inferInsert;

/**
 * Tickets table - main support ticket data
 */
export const tickets = mysqlTable("tickets", {
  id: int("id").autoincrement().primaryKey(),
  ticketId: varchar("ticketId", { length: 20 }).notNull().unique(), // Human-readable ID like TKT-001
  userId: int("userId").notNull(),
  departmentId: int("departmentId"),
  title: varchar("title", { length: 255 }).notNull(),
  description: text("description").notNull(),
  language: varchar("language", { length: 10 }).default("en"),
  
  // AI Routing fields
  classifiedDepartmentId: int("classifiedDepartmentId"),
  priority: mysqlEnum("priority", ["low", "medium", "high", "critical"]).default("medium"),
  aiConfidence: decimal("aiConfidence", { precision: 5, scale: 2 }).default("0.00"), // 0-100
  routingAccuracy: boolean("routingAccuracy").default(false), // Whether human confirmed routing
  
  // Status tracking
  status: mysqlEnum("status", ["open", "in_progress", "waiting", "resolved", "closed"]).default("open"),
  assignedTo: int("assignedTo"),
  
  // Metadata
  voiceInput: boolean("voiceInput").default(false),
  tags: json("tags"), // Array of tags
  
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  resolvedAt: timestamp("resolvedAt"),
});

export type Ticket = typeof tickets.$inferSelect;
export type InsertTicket = typeof tickets.$inferInsert;

/**
 * Ticket history/timeline - track ticket status changes and interactions
 */
export const ticketHistory = mysqlTable("ticketHistory", {
  id: int("id").autoincrement().primaryKey(),
  ticketId: int("ticketId").notNull(),
  action: mysqlEnum("action", [
    "created",
    "status_changed",
    "priority_changed",
    "assigned",
    "commented",
    "resolved",
    "reopened",
    "routed"
  ]).notNull(),
  previousValue: text("previousValue"),
  newValue: text("newValue"),
  userId: int("userId"),
  notes: text("notes"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type TicketHistory = typeof ticketHistory.$inferSelect;
export type InsertTicketHistory = typeof ticketHistory.$inferInsert;

/**
 * Daily analytics snapshot - for performance metrics
 */
export const analyticsSnapshot = mysqlTable("analyticsSnapshot", {
  id: int("id").autoincrement().primaryKey(),
  date: timestamp("date").notNull(),
  totalTickets: int("totalTickets").default(0),
  openTickets: int("openTickets").default(0),
  resolvedTickets: int("resolvedTickets").default(0),
  avgResolutionTime: decimal("avgResolutionTime", { precision: 10, scale: 2 }).default("0"),
  routingAccuracy: decimal("routingAccuracy", { precision: 5, scale: 2 }).default("0"),
  avgAiConfidence: decimal("avgAiConfidence", { precision: 5, scale: 2 }).default("0"),
  highPriorityCount: int("highPriorityCount").default(0),
  departmentDistribution: json("departmentDistribution"), // { departmentId: count }
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type AnalyticsSnapshot = typeof analyticsSnapshot.$inferSelect;
export type InsertAnalyticsSnapshot = typeof analyticsSnapshot.$inferInsert;
