CREATE TABLE `analyticsSnapshot` (
	`id` int AUTO_INCREMENT NOT NULL,
	`date` timestamp NOT NULL,
	`totalTickets` int DEFAULT 0,
	`openTickets` int DEFAULT 0,
	`resolvedTickets` int DEFAULT 0,
	`avgResolutionTime` decimal(10,2) DEFAULT '0',
	`routingAccuracy` decimal(5,2) DEFAULT '0',
	`avgAiConfidence` decimal(5,2) DEFAULT '0',
	`highPriorityCount` int DEFAULT 0,
	`departmentDistribution` json,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `analyticsSnapshot_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `departments` (
	`id` int AUTO_INCREMENT NOT NULL,
	`name` varchar(100) NOT NULL,
	`description` text,
	`icon` varchar(50),
	`color` varchar(20) DEFAULT '#3b82f6',
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `departments_id` PRIMARY KEY(`id`),
	CONSTRAINT `departments_name_unique` UNIQUE(`name`)
);
--> statement-breakpoint
CREATE TABLE `ticketHistory` (
	`id` int AUTO_INCREMENT NOT NULL,
	`ticketId` int NOT NULL,
	`action` enum('created','status_changed','priority_changed','assigned','commented','resolved','reopened','routed') NOT NULL,
	`previousValue` text,
	`newValue` text,
	`userId` int,
	`notes` text,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `ticketHistory_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `tickets` (
	`id` int AUTO_INCREMENT NOT NULL,
	`ticketId` varchar(20) NOT NULL,
	`userId` int NOT NULL,
	`departmentId` int,
	`title` varchar(255) NOT NULL,
	`description` text NOT NULL,
	`language` varchar(10) DEFAULT 'en',
	`classifiedDepartmentId` int,
	`priority` enum('low','medium','high','critical') DEFAULT 'medium',
	`aiConfidence` decimal(5,2) DEFAULT '0.00',
	`routingAccuracy` boolean DEFAULT false,
	`status` enum('open','in_progress','waiting','resolved','closed') DEFAULT 'open',
	`assignedTo` int,
	`voiceInput` boolean DEFAULT false,
	`tags` json,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	`resolvedAt` timestamp,
	CONSTRAINT `tickets_id` PRIMARY KEY(`id`),
	CONSTRAINT `tickets_ticketId_unique` UNIQUE(`ticketId`)
);
