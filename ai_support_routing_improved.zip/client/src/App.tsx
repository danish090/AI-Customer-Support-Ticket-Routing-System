import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import DashboardLayout from "./components/DashboardLayout";
import Dashboard from "./pages/Dashboard";
import SubmitTicket from "./pages/SubmitTicket";
import Tickets from "./pages/Tickets";
import Analytics from "./pages/Analytics";
import TicketDetail from "./pages/TicketDetail";

function Router() {
  return (
    <Switch>
      <Route path={"/"}>
        <DashboardLayout>
          <Dashboard />
        </DashboardLayout>
      </Route>
      <Route path={"/submit"}>
        <DashboardLayout>
          <SubmitTicket />
        </DashboardLayout>
      </Route>
      <Route path={"/tickets"}>
        <DashboardLayout>
          <Tickets />
        </DashboardLayout>
      </Route>
      <Route path={"/tickets/:id"}>
        {(params) => (
          <DashboardLayout>
            <TicketDetail ticketId={parseInt(params.id)} />
          </DashboardLayout>
        )}
      </Route>
      <Route path={"/analytics"}>
        <DashboardLayout>
          <Analytics />
        </DashboardLayout>
      </Route>
      <Route path={"/404"} component={NotFound} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="light">
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
