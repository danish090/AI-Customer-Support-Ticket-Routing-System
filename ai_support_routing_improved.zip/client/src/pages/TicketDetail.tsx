import { trpc } from "@/lib/trpc";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Loader2, ArrowLeft, CheckCircle, AlertCircle } from "lucide-react";
import { useLocation } from "wouter";
import { toast } from "sonner";

interface TicketDetailProps {
  ticketId: number;
}

export default function TicketDetail({ ticketId }: TicketDetailProps) {
  const [, navigate] = useLocation();
  const { data: ticketData, isLoading } = trpc.tickets.getById.useQuery({ id: ticketId });
  const updateTicket = trpc.tickets.update.useMutation();
  const confirmRouting = trpc.tickets.confirmRouting.useMutation();

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="w-8 h-8 animate-spin text-accent" />
      </div>
    );
  }

  if (!ticketData?.ticket) {
    return (
      <div className="space-y-6">
        <Button variant="outline" onClick={() => navigate("/tickets")}>
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back to Tickets
        </Button>
        <Card className="card-base text-center py-12">
          <p className="text-muted-foreground">Ticket not found</p>
        </Card>
      </div>
    );
  }

  const { ticket, history, department } = ticketData;

  const handleStatusChange = async (newStatus: string) => {
    try {
      await updateTicket.mutateAsync({
        id: ticketId,
        status: newStatus as any,
      });
      toast.success("Ticket status updated");
    } catch (error) {
      toast.error("Failed to update ticket");
    }
  };

  const handleConfirmRouting = async (accurate: boolean) => {
    try {
      await confirmRouting.mutateAsync({
        id: ticketId,
        accurate,
      });
      toast.success(accurate ? "Routing confirmed" : "Routing disputed");
    } catch (error) {
      toast.error("Failed to confirm routing");
    }
  };

  return (
    <div className="space-y-6 animate-in">
      {/* Header */}
      <div className="flex items-center gap-4">
        <Button variant="outline" onClick={() => navigate("/tickets")}>
          <ArrowLeft className="w-4 h-4" />
        </Button>
        <div>
          <h1 className="text-3xl font-bold text-foreground">{ticket.title}</h1>
          <p className="text-muted-foreground mt-1">{ticket.ticketId}</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Main Content */}
        <div className="lg:col-span-2 space-y-6">
          {/* Description */}
          <Card className="card-base">
            <h2 className="text-lg font-bold mb-4">Description</h2>
            <p className="text-foreground whitespace-pre-wrap">{ticket.description}</p>
          </Card>

          {/* Timeline/History */}
          <Card className="card-base">
            <h2 className="text-lg font-bold mb-4">Activity Timeline</h2>
            {history && history.length > 0 ? (
              <div className="space-y-4">
                {history.map((entry: any, idx: number) => (
                  <div key={idx} className="flex gap-4 pb-4 border-b border-border last:border-b-0">
                    <div className="flex-shrink-0">
                      <div className="w-8 h-8 rounded-full bg-gradient-primary flex items-center justify-center text-white text-xs font-bold">
                        {idx + 1}
                      </div>
                    </div>
                    <div className="flex-1">
                      <p className="font-medium text-foreground capitalize">
                        {entry.action.replace(/_/g, " ")}
                      </p>
                      {entry.newValue && (
                        <p className="text-sm text-muted-foreground mt-1">{entry.newValue}</p>
                      )}
                      <p className="text-xs text-muted-foreground mt-2">
                        {new Date(entry.createdAt).toLocaleString()}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-muted-foreground">No activity yet</p>
            )}
          </Card>
        </div>

        {/* Sidebar */}
        <div className="space-y-6">
          {/* Status Card */}
          <Card className="card-base">
            <h3 className="font-bold mb-3">Status</h3>
            <Select value={ticket.status || "open"} onValueChange={handleStatusChange}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="open">Open</SelectItem>
                <SelectItem value="in_progress">In Progress</SelectItem>
                <SelectItem value="waiting">Waiting</SelectItem>
                <SelectItem value="resolved">Resolved</SelectItem>
                <SelectItem value="closed">Closed</SelectItem>
              </SelectContent>
            </Select>
          </Card>

          {/* Priority Card */}
          <Card className="card-base">
            <h3 className="font-bold mb-3">Priority</h3>
            <span className={`priority-${ticket.priority || 'medium'}`}>
              {(ticket.priority || 'medium').charAt(0).toUpperCase() + (ticket.priority || 'medium').slice(1)}
            </span>
          </Card>

          {/* AI Routing Card */}
          <Card className="card-base space-y-3">
            <h3 className="font-bold">AI Routing</h3>
            <div>
              <p className="text-sm text-muted-foreground">Department</p>
              <p className="font-medium">{department?.name || "Not assigned"}</p>
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Confidence</p>
              <div className="flex items-center gap-2 mt-1">
                <div className="flex-1 h-2 bg-muted rounded-full overflow-hidden">
                  <div
                    className="h-full bg-gradient-primary"
                    style={{ width: `${Number(ticket.aiConfidence)}%` }}
                  />
                </div>
                <span className="text-sm font-bold">{Number(ticket.aiConfidence).toFixed(0)}%</span>
              </div>
            </div>

            {/* Routing Feedback */}
            <div className="pt-3 border-t border-border space-y-2">
              <p className="text-sm text-muted-foreground">Is this routing accurate?</p>
              <div className="flex gap-2">
                <Button
                  size="sm"
                  variant={ticket.routingAccuracy ? "default" : "outline"}
                  onClick={() => handleConfirmRouting(true)}
                  disabled={confirmRouting.isPending}
                  className="flex-1"
                >
                  <CheckCircle className="w-4 h-4 mr-1" />
                  Yes
                </Button>
                <Button
                  size="sm"
                  variant={ticket.routingAccuracy === false ? "destructive" : "outline"}
                  onClick={() => handleConfirmRouting(false)}
                  disabled={confirmRouting.isPending}
                  className="flex-1"
                >
                  <AlertCircle className="w-4 h-4 mr-1" />
                  No
                </Button>
              </div>
            </div>
          </Card>

          {/* Metadata */}
          <Card className="card-base space-y-3 text-sm">
            <div>
              <p className="text-muted-foreground">Created</p>
              <p className="font-medium">{new Date(ticket.createdAt).toLocaleString()}</p>
            </div>
            <div>
              <p className="text-muted-foreground">Language</p>
              <p className="font-medium">{(ticket.language || "en").toUpperCase()}</p>
            </div>
            {ticket.tags ? (() => {
              try {
                const tags = JSON.parse(ticket.tags as any) as any[];
                return (
                  <div>
                    <p className="text-muted-foreground mb-2">Tags</p>
                    <div className="flex flex-wrap gap-2">
                      {tags.map((tag: any) => (
                        <span key={String(tag)} className="badge-primary">
                          {String(tag)}
                        </span>
                      ))}
                    </div>
                  </div>
                );
              } catch {
                return null;
              }
            })() : null}
          </Card>
        </div>
      </div>
    </div>
  );
}
