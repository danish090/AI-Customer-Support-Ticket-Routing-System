import { trpc } from "@/lib/trpc";
import { Card } from "@/components/ui/card";
import { BarChart, Bar, LineChart, Line, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from "recharts";
import { TrendingUp, Users, Target, Award } from "lucide-react";

export default function Analytics() {
  const { data: stats } = trpc.analytics.stats.useQuery();
  const { data: volumeByDept } = trpc.analytics.volumeByDepartment.useQuery();
  const { data: priorityDist } = trpc.analytics.priorityDistribution.useQuery();
  const { data: accuracyTrend } = trpc.analytics.accuracyTrend.useQuery();

  const COLORS = ["#3b82f6", "#10b981", "#f59e0b", "#ef4444"];

  const metricCards = [
    {
      title: "Overall Accuracy",
      value: `${stats?.routingAccuracy?.toFixed(1) ?? 0}%`,
      icon: <Target className="w-5 h-5" />,
      gradient: "bg-gradient-primary",
    },
    {
      title: "Cumulative RL Reward",
      value: "0",
      icon: <Award className="w-5 h-5" />,
      gradient: "bg-gradient-success",
    },
    {
      title: "Avg AI Confidence",
      value: `${stats?.avgConfidence?.toFixed(1) ?? 0}%`,
      icon: <TrendingUp className="w-5 h-5" />,
      gradient: "bg-gradient-cyan",
    },
    {
      title: "High Priority Load",
      value: "0",
      icon: <Users className="w-5 h-5" />,
      gradient: "bg-gradient-danger",
    },
  ];

  const volumeData = volumeByDept
    ? Object.entries(volumeByDept).map(([name, value]) => ({ name, value }))
    : [];

  const priorityData = priorityDist
    ? [
        { name: "Low", value: priorityDist.low },
        { name: "Medium", value: priorityDist.medium },
        { name: "High", value: priorityDist.high },
        { name: "Critical", value: priorityDist.critical },
      ]
    : [];

  return (
    <div className="space-y-8 animate-in">
      {/* Header */}
      <div>
        <h1 className="text-4xl font-bold text-foreground">System Analytics</h1>
        <p className="text-muted-foreground mt-2">Performance metrics, routing accuracy, and reinforcement learning telemetry.</p>
      </div>

      {/* Metric Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {metricCards.map((card, idx) => (
          <Card key={idx} className="card-hover">
            <div className="flex items-start justify-between">
              <div className="flex-1">
                <p className="text-sm font-medium text-muted-foreground">{card.title}</p>
                <p className="text-3xl font-bold mt-2">{card.value}</p>
              </div>
              <div className={`${card.gradient} rounded-lg p-3 text-white`}>
                {card.icon}
              </div>
            </div>
          </Card>
        ))}
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Volume by Department */}
        <Card className="card-base">
          <h2 className="text-lg font-bold mb-4">Volume by Department</h2>
          <p className="text-sm text-muted-foreground mb-4">Ticket distribution across business units</p>
          {volumeData.length > 0 ? (
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={volumeData}>
                <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
                <XAxis dataKey="name" stroke="var(--muted-foreground)" />
                <YAxis stroke="var(--muted-foreground)" />
                <Tooltip
                  contentStyle={{
                    backgroundColor: "var(--card)",
                    border: "1px solid var(--border)",
                    borderRadius: "0.5rem",
                  }}
                />
                <Bar dataKey="value" fill="#3b82f6" radius={[8, 8, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          ) : (
            <div className="h-[300px] flex items-center justify-center text-muted-foreground">
              No data available
            </div>
          )}
        </Card>

        {/* Priority Distribution */}
        <Card className="card-base">
          <h2 className="text-lg font-bold mb-4">Priority Distribution</h2>
          <p className="text-sm text-muted-foreground mb-4">Breakdown of assigned severity levels</p>
          {priorityData.some(d => d.value > 0) ? (
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={priorityData}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ name, value }) => `${name}: ${value}`}
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="value"
                >
                  {priorityData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip
                  contentStyle={{
                    backgroundColor: "var(--card)",
                    border: "1px solid var(--border)",
                    borderRadius: "0.5rem",
                  }}
                />
              </PieChart>
            </ResponsiveContainer>
          ) : (
            <div className="h-[300px] flex items-center justify-center text-muted-foreground">
              No data available
            </div>
          )}
        </Card>
      </div>

      {/* Model Accuracy Trend */}
      <Card className="card-base">
        <h2 className="text-lg font-bold mb-4">Model Accuracy Trend</h2>
        <p className="text-sm text-muted-foreground mb-4">Daily routing accuracy based on human feedback</p>
        {accuracyTrend && accuracyTrend.length > 0 ? (
          <ResponsiveContainer width="100%" height={400}>
            <LineChart data={accuracyTrend}>
              <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
              <XAxis dataKey="date" stroke="var(--muted-foreground)" />
              <YAxis stroke="var(--muted-foreground)" />
              <Tooltip
                contentStyle={{
                  backgroundColor: "var(--card)",
                  border: "1px solid var(--border)",
                  borderRadius: "0.5rem",
                }}
              />
              <Legend />
              <Line
                type="monotone"
                dataKey="accuracy"
                stroke="#3b82f6"
                dot={{ fill: "#3b82f6" }}
                name="Accuracy (%)"
              />
              <Line
                type="monotone"
                dataKey="confidence"
                stroke="#10b981"
                dot={{ fill: "#10b981" }}
                name="Confidence (%)"
              />
            </LineChart>
          </ResponsiveContainer>
        ) : (
          <div className="h-[400px] flex items-center justify-center text-muted-foreground">
            No data available
          </div>
        )}
      </Card>
    </div>
  );
}
