import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Search, Filter, ArrowUpDown } from "lucide-react";
import { useLocation } from "wouter";

export default function Tickets() {
  const [, navigate] = useLocation();
  const [search, setSearch] = useState("");
  const [departmentFilter, setDepartmentFilter] = useState<string | undefined>();
  const [priorityFilter, setPriorityFilter] = useState<string | undefined>();
  const [statusFilter, setStatusFilter] = useState<string | undefined>();
  const [sortBy, setSortBy] = useState<"date" | "priority">("date");

  const { data: departments } = trpc.departments.list.useQuery();
  const { data: tickets, isLoading } = trpc.tickets.list.useQuery({
    search: search || undefined,
    departmentId: departmentFilter ? parseInt(departmentFilter) : undefined,
    priority: priorityFilter,
    status: statusFilter,
    limit: 100,
  });

  const sortedTickets = tickets
    ? [...tickets].sort((a: any, b: any) => {
        if (sortBy === "date") {
          return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
        } else {
          const priorityOrder = { critical: 0, high: 1, medium: 2, low: 3 };
          return (priorityOrder[a.priority as keyof typeof priorityOrder] || 4) -
                 (priorityOrder[b.priority as keyof typeof priorityOrder] || 4);
        }
      })
    : [];

  const handleClearFilters = () => {
    setSearch("");
    setDepartmentFilter(undefined);
    setPriorityFilter(undefined);
    setStatusFilter(undefined);
  };

  return (
    <div className="space-y-6 animate-in">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-4xl font-bold text-foreground">Tickets</h1>
          <p className="text-muted-foreground mt-2">Manage and track all support tickets</p>
        </div>
        <Button onClick={() => navigate("/submit")} className="btn-primary">
          New Ticket
        </Button>
      </div>

      {/* Search & Filters */}
      <Card className="card-base space-y-4">
        {/* Search Bar */}
        <div className="relative">
          <Search className="absolute left-3 top-3 w-5 h-5 text-muted-foreground" />
          <Input
            placeholder="Search tickets by ID or content..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-10 focus-ring"
          />
        </div>

        {/* Filter Controls */}
        <div className="grid grid-cols-1 md:grid-cols-5 gap-3">
          <Select value={departmentFilter || ""} onValueChange={setDepartmentFilter}>
            <SelectTrigger>
              <SelectValue placeholder="All Departments" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="">All Departments</SelectItem>
              {departments?.map((dept: any) => (
                <SelectItem key={dept.id} value={dept.id.toString()}>
                  {dept.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>

          <Select value={priorityFilter || ""} onValueChange={setPriorityFilter}>
            <SelectTrigger>
              <SelectValue placeholder="All Priorities" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="">All Priorities</SelectItem>
              <SelectItem value="low">Low</SelectItem>
              <SelectItem value="medium">Medium</SelectItem>
              <SelectItem value="high">High</SelectItem>
              <SelectItem value="critical">Critical</SelectItem>
            </SelectContent>
          </Select>

          <Select value={statusFilter || ""} onValueChange={setStatusFilter}>
            <SelectTrigger>
              <SelectValue placeholder="All Statuses" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="">All Statuses</SelectItem>
              <SelectItem value="open">Open</SelectItem>
              <SelectItem value="in_progress">In Progress</SelectItem>
              <SelectItem value="waiting">Waiting</SelectItem>
              <SelectItem value="resolved">Resolved</SelectItem>
              <SelectItem value="closed">Closed</SelectItem>
            </SelectContent>
          </Select>

          <Select value={sortBy} onValueChange={(v) => setSortBy(v as any)}>
            <SelectTrigger>
              <SelectValue placeholder="Sort by" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="date">Newest First</SelectItem>
              <SelectItem value="priority">Priority</SelectItem>
            </SelectContent>
          </Select>

          <Button
            variant="outline"
            onClick={handleClearFilters}
            className="w-full"
          >
            <Filter className="w-4 h-4 mr-2" />
            Clear
          </Button>
        </div>

        {/* Results Count */}
        <div className="text-sm text-muted-foreground">
          Showing {sortedTickets.length} of {tickets?.length ?? 0} tickets
        </div>
      </Card>

      {/* Tickets Table */}
      <Card className="card-base overflow-hidden">
        {isLoading ? (
          <div className="text-center py-12">
            <p className="text-muted-foreground">Loading tickets...</p>
          </div>
        ) : sortedTickets.length === 0 ? (
          <div className="text-center py-12">
            <p className="text-muted-foreground">No tickets found matching the criteria.</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="border-b border-border bg-muted/50">
                <tr>
                  <th className="px-6 py-3 text-left text-sm font-semibold text-foreground">ID</th>
                  <th className="px-6 py-3 text-left text-sm font-semibold text-foreground">Title</th>
                  <th className="px-6 py-3 text-left text-sm font-semibold text-foreground">Department</th>
                  <th className="px-6 py-3 text-left text-sm font-semibold text-foreground">Priority</th>
                  <th className="px-6 py-3 text-left text-sm font-semibold text-foreground">Status</th>
                  <th className="px-6 py-3 text-left text-sm font-semibold text-foreground">Confidence</th>
                  <th className="px-6 py-3 text-left text-sm font-semibold text-foreground">Created</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {sortedTickets.map((ticket: any) => (
                  <tr
                    key={ticket.id}
                    className="hover:bg-muted/50 transition-colors cursor-pointer"
                    onClick={() => navigate(`/tickets/${ticket.id}`)}
                  >
                    <td className="px-6 py-4 text-sm font-medium text-accent">{ticket.ticketId}</td>
                    <td className="px-6 py-4 text-sm text-foreground truncate max-w-xs">{ticket.title}</td>
                    <td className="px-6 py-4 text-sm text-muted-foreground">{ticket.classifiedDepartmentId ? "Support" : "-"}</td>
                    <td className="px-6 py-4">
                      <span className={`priority-${ticket.priority}`}>
                        {ticket.priority.charAt(0).toUpperCase() + ticket.priority.slice(1)}
                      </span>
                    </td>
                    <td className="px-6 py-4">
                      <span className={`status-${ticket.status}`}>
                        {ticket.status.replace(/_/g, " ").charAt(0).toUpperCase() + ticket.status.replace(/_/g, " ").slice(1)}
                      </span>
                    </td>
                    <td className="px-6 py-4 text-sm">
                      <div className="flex items-center gap-2">
                        <div className="w-16 h-2 bg-muted rounded-full overflow-hidden">
                          <div
                            className="h-full bg-gradient-primary"
                            style={{ width: `${ticket.aiConfidence}%` }}
                          />
                        </div>
                        <span className="text-xs font-medium">{ticket.aiConfidence.toFixed(0)}%</span>
                      </div>
                    </td>
                    <td className="px-6 py-4 text-sm text-muted-foreground">
                      {new Date(ticket.createdAt).toLocaleDateString()}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Card>
    </div>
  );
}
