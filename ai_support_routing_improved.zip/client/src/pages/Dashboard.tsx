import { trpc } from "@/lib/trpc";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Loader2, TrendingUp, AlertCircle, CheckCircle, Clock } from "lucide-react";
import { useLocation } from "wouter";

export default function Dashboard() {
  const [, navigate] = useLocation();
  const { data: stats, isLoading } = trpc.analytics.stats.useQuery();
  const { data: recentTickets } = trpc.tickets.list.useQuery({ limit: 5 });

  const metricCards = [
    {
      title: "Total Tickets",
      value: stats?.totalTickets ?? 0,
      icon: <AlertCircle className="w-5 h-5" />,
      gradient: "bg-gradient-primary",
      color: "text-blue-600",
    },
    {
      title: "Open Tickets",
      value: stats?.openTickets ?? 0,
      icon: <Clock className="w-5 h-5" />,
      gradient: "bg-gradient-warning",
      color: "text-yellow-600",
    },
    {
      title: "Routing Accuracy",
      value: `${stats?.routingAccuracy?.toFixed(1) ?? 0}%`,
      icon: <TrendingUp className="w-5 h-5" />,
      gradient: "bg-gradient-success",
      color: "text-green-600",
    },
    {
      title: "Avg Confidence",
      value: `${stats?.avgConfidence?.toFixed(1) ?? 0}%`,
      icon: <CheckCircle className="w-5 h-5" />,
      gradient: "bg-gradient-cyan",
      color: "text-cyan-600",
    },
  ];

  return (
    <div className="space-y-8 animate-in">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-4xl font-bold text-foreground">Dashboard</h1>
          <p className="text-muted-foreground mt-2">Welcome to AI Support Routing System</p>
        </div>
        <Button onClick={() => navigate("/submit")} className="btn-primary">
          Submit New Ticket
        </Button>
      </div>

      {/* Metric Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {metricCards.map((card, idx) => (
          <Card key={idx} className="card-hover overflow-hidden">
            <div className="flex items-start justify-between">
              <div className="flex-1">
                <p className="text-sm font-medium text-muted-foreground">{card.title}</p>
                <p className="text-3xl font-bold mt-2">{isLoading ? <Loader2 className="animate-spin" /> : card.value}</p>
              </div>
              <div className={`${card.gradient} rounded-lg p-3 text-white`}>
                {card.icon}
              </div>
            </div>
          </Card>
        ))}
      </div>

      {/* Recent Tickets */}
      <Card className="card-base">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-xl font-bold">Recent AI-Routed Tickets</h2>
          <Button variant="outline" onClick={() => navigate("/tickets")}>
            View all
          </Button>
        </div>

        {!recentTickets || recentTickets.length === 0 ? (
          <div className="text-center py-12">
            <p className="text-muted-foreground">No tickets found.</p>
          </div>
        ) : (
          <div className="space-y-3">
            {recentTickets.map((ticket: any) => (
              <div
                key={ticket.id}
                className="flex items-center justify-between p-4 border border-border rounded-lg hover:bg-muted transition-colors cursor-pointer"
                onClick={() => navigate(`/tickets/${ticket.id}`)}
              >
                <div className="flex-1">
                  <p className="font-medium text-foreground">{ticket.title}</p>
                  <p className="text-sm text-muted-foreground mt-1">{ticket.ticketId}</p>
                </div>
                <div className="flex items-center gap-3">
                  <span className={`priority-${ticket.priority}`}>
                    {ticket.priority.charAt(0).toUpperCase() + ticket.priority.slice(1)}
                  </span>
                  <span className={`status-${ticket.status}`}>
                    {ticket.status.replace(/_/g, " ").charAt(0).toUpperCase() + ticket.status.replace(/_/g, " ").slice(1)}
                  </span>
                </div>
              </div>
            ))}
          </div>
        )}
      </Card>
    </div>
  );
}
