import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Loader2, Mic, MicOff, Send } from "lucide-react";
import { toast } from "sonner";
import { useLocation } from "wouter";

const LANGUAGES = [
  { code: "en", name: "English", flag: "🇺🇸" },
  { code: "es", name: "Español", flag: "🇪🇸" },
  { code: "fr", name: "Français", flag: "🇫🇷" },
  { code: "de", name: "Deutsch", flag: "🇩🇪" },
  { code: "ja", name: "日本語", flag: "🇯🇵" },
  { code: "zh", name: "中文", flag: "🇨🇳" },
];

export default function SubmitTicket() {
  const [, navigate] = useLocation();
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [language, setLanguage] = useState("en");
  const [isRecording, setIsRecording] = useState(false);
  const [tags, setTags] = useState<string[]>([]);
  const [tagInput, setTagInput] = useState("");

  const createTicket = trpc.tickets.create.useMutation();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!title.trim() || !description.trim()) {
      toast.error("Please fill in all required fields");
      return;
    }

    try {
      const result = await createTicket.mutateAsync({
        title,
        description,
        language,
        voiceInput: false,
        tags,
      });

      toast.success(`Ticket ${result.ticketId} created successfully!`);
      setTitle("");
      setDescription("");
      setLanguage("en");
      setTags([]);
      
      setTimeout(() => navigate("/tickets"), 1500);
    } catch (error) {
      toast.error("Failed to create ticket");
    }
  };

  const handleAddTag = () => {
    if (tagInput.trim() && !tags.includes(tagInput.trim())) {
      setTags([...tags, tagInput.trim()]);
      setTagInput("");
    }
  };

  const handleRemoveTag = (tag: string) => {
    setTags(tags.filter(t => t !== tag));
  };

  const handleVoiceInput = async () => {
    if (!("webkitSpeechRecognition" in window)) {
      toast.error("Speech recognition not supported in your browser");
      return;
    }

    const SpeechRecognition = (window as any).webkitSpeechRecognition;
    const recognition = new SpeechRecognition();

    recognition.continuous = true;
    recognition.interimResults = true;
    recognition.lang = language;

    recognition.onstart = () => {
      setIsRecording(true);
      toast.success("Listening...");
    };

    recognition.onresult = (event: any) => {
      let interimTranscript = "";
      for (let i = event.resultIndex; i < event.results.length; i++) {
        const transcript = event.results[i][0].transcript;
        if (event.results[i].isFinal) {
          setDescription(prev => prev + (prev ? " " : "") + transcript);
        } else {
          interimTranscript += transcript;
        }
      }
    };

    recognition.onerror = () => {
      toast.error("Speech recognition error");
      setIsRecording(false);
    };

    recognition.onend = () => {
      setIsRecording(false);
      toast.success("Recording stopped");
    };

    if (isRecording) {
      recognition.stop();
    } else {
      recognition.start();
    }
  };

  const selectedLanguage = LANGUAGES.find(l => l.code === language);

  return (
    <div className="max-w-2xl mx-auto space-y-6 animate-in">
      {/* Header */}
      <div>
        <h1 className="text-4xl font-bold text-foreground">Submit New Ticket</h1>
        <p className="text-muted-foreground mt-2">
          Describe your issue. Our AI will automatically classify, prioritize, and route it to the correct department.
        </p>
      </div>

      {/* Form Card */}
      <Card className="card-base">
        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Language Selector */}
          <div className="space-y-2">
            <label className="text-sm font-medium text-foreground">Language</label>
            <Select value={language} onValueChange={setLanguage}>
              <SelectTrigger className="w-full">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {LANGUAGES.map(lang => (
                  <SelectItem key={lang.code} value={lang.code}>
                    <span className="flex items-center gap-2">
                      <span>{lang.flag}</span>
                      <span>{lang.name}</span>
                    </span>
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Title */}
          <div className="space-y-2">
            <label className="text-sm font-medium text-foreground">Issue Title *</label>
            <Input
              placeholder="Brief summary of your issue"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="focus-ring"
            />
          </div>

          {/* Description */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <label className="text-sm font-medium text-foreground">Description *</label>
              <Button
                type="button"
                variant="outline"
                size="sm"
                onClick={handleVoiceInput}
                className={isRecording ? "bg-red-100 text-red-700 hover:bg-red-200" : ""}
              >
                {isRecording ? (
                  <>
                    <MicOff className="w-4 h-4 mr-2" />
                    Stop Recording
                  </>
                ) : (
                  <>
                    <Mic className="w-4 h-4 mr-2" />
                    Start Voice Input
                  </>
                )}
              </Button>
            </div>
            <Textarea
              placeholder="Describe your issue in detail..."
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              rows={6}
              className="focus-ring resize-none"
            />
            <p className="text-xs text-muted-foreground">
              {description.length} characters
            </p>
          </div>

          {/* Tags */}
          <div className="space-y-2">
            <label className="text-sm font-medium text-foreground">Tags (Optional)</label>
            <div className="flex gap-2">
              <Input
                placeholder="Add a tag..."
                value={tagInput}
                onChange={(e) => setTagInput(e.target.value)}
                onKeyPress={(e) => {
                  if (e.key === "Enter") {
                    e.preventDefault();
                    handleAddTag();
                  }
                }}
                className="focus-ring"
              />
              <Button type="button" variant="outline" onClick={handleAddTag}>
                Add
              </Button>
            </div>
            {tags.length > 0 && (
              <div className="flex flex-wrap gap-2 mt-2">
                {tags.map(tag => (
                  <div
                    key={tag}
                    className="badge-primary flex items-center gap-2"
                  >
                    {tag}
                    <button
                      type="button"
                      onClick={() => handleRemoveTag(tag)}
                      className="text-xs font-bold hover:opacity-70"
                    >
                      ×
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Actions */}
          <div className="flex gap-3 pt-4">
            <Button
              type="submit"
              disabled={createTicket.isPending}
              className="btn-primary flex-1"
            >
              {createTicket.isPending ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Submitting...
                </>
              ) : (
                <>
                  <Send className="w-4 h-4 mr-2" />
                  Submit & Route Ticket
                </>
              )}
            </Button>
            <Button
              type="button"
              variant="outline"
              onClick={() => {
                setTitle("");
                setDescription("");
                setLanguage("en");
                setTags([]);
              }}
            >
              Clear
            </Button>
          </div>
        </form>
      </Card>

      {/* Info Box */}
      <Card className="card-base bg-blue-50 dark:bg-blue-950/30 border-blue-200 dark:border-blue-800">
        <div className="flex gap-3">
          <div className="text-2xl">ℹ️</div>
          <div>
            <p className="font-medium text-blue-900 dark:text-blue-100">AI-Powered Routing</p>
            <p className="text-sm text-blue-800 dark:text-blue-200 mt-1">
              Our AI system will automatically analyze your ticket, detect the priority level, classify the issue type, and route it to the most appropriate department. You'll receive a confidence score for the routing decision.
            </p>
          </div>
        </div>
      </Card>
    </div>
  );
}
