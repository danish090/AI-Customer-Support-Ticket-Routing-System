import { eq, desc, and, like, ilike } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { InsertUser, users, tickets, departments, ticketHistory, analyticsSnapshot } from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

/**
 * Ticket queries
 */

export async function createTicket(data: typeof tickets.$inferInsert) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  const result = await db.insert(tickets).values(data);
  return result;
}

export async function getTicketById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  
  const result = await db.select().from(tickets).where(eq(tickets.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getTicketByTicketId(ticketId: string) {
  const db = await getDb();
  if (!db) return undefined;
  
  const result = await db.select().from(tickets).where(eq(tickets.ticketId, ticketId)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function listTickets(filters?: {
  departmentId?: number;
  priority?: string;
  status?: string;
  search?: string;
  limit?: number;
  offset?: number;
}) {
  const db = await getDb();
  if (!db) return [];
  
  const conditions: any[] = [];
  if (filters?.departmentId) {
    conditions.push(eq(tickets.classifiedDepartmentId, filters.departmentId));
  }
  if (filters?.priority) {
    conditions.push(eq(tickets.priority, filters.priority as any));
  }
  if (filters?.status) {
    conditions.push(eq(tickets.status, filters.status as any));
  }
  if (filters?.search) {
    conditions.push(
      ilike(tickets.title, `%${filters.search}%`)
    );
  }
  
  let baseQuery = db.select().from(tickets);
  
  if (conditions.length > 0) {
    baseQuery = baseQuery.where(and(...conditions)) as any;
  }
  
  let finalQuery = baseQuery.orderBy(desc(tickets.createdAt)) as any;
  
  if (filters?.limit) {
    finalQuery = finalQuery.limit(filters.limit);
  }
  if (filters?.offset) {
    finalQuery = finalQuery.offset(filters.offset);
  }
  
  return await finalQuery;
}

export async function updateTicket(id: number, data: Partial<typeof tickets.$inferInsert>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  return await db.update(tickets).set({
    ...data,
    updatedAt: new Date(),
  }).where(eq(tickets.id, id));
}

/**
 * Department queries
 */

export async function getDepartments() {
  const db = await getDb();
  if (!db) return [];
  
  return await db.select().from(departments);
}

export async function getDepartmentById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  
  const result = await db.select().from(departments).where(eq(departments.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function createDepartment(data: typeof departments.$inferInsert) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  return await db.insert(departments).values(data);
}

/**
 * Ticket history queries
 */

export async function addTicketHistory(data: typeof ticketHistory.$inferInsert) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  return await db.insert(ticketHistory).values(data);
}

export async function getTicketHistory(ticketId: number) {
  const db = await getDb();
  if (!db) return [];
  
  return await db.select().from(ticketHistory)
    .where(eq(ticketHistory.ticketId, ticketId))
    .orderBy(desc(ticketHistory.createdAt));
}

/**
 * Analytics queries
 */

export async function getAnalyticsSnapshot(date: Date) {
  const db = await getDb();
  if (!db) return undefined;
  
  const result = await db.select().from(analyticsSnapshot)
    .where(eq(analyticsSnapshot.date, date))
    .limit(1);
  
  return result.length > 0 ? result[0] : undefined;
}

export async function createAnalyticsSnapshot(data: typeof analyticsSnapshot.$inferInsert) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  return await db.insert(analyticsSnapshot).values(data);
}

export async function getTicketStats() {
  const db = await getDb();
  if (!db) return null;
  
  const allTickets = await db.select().from(tickets);
  const openTickets = allTickets.filter(t => t.status === 'open');
  const resolvedTickets = allTickets.filter(t => t.status === 'resolved');
  
  const avgConfidence = allTickets.length > 0
    ? allTickets.reduce((sum, t) => sum + (Number(t.aiConfidence) || 0), 0) / allTickets.length
    : 0;
  
  const routingAccuracyCount = allTickets.filter(t => t.routingAccuracy).length;
  const routingAccuracy = allTickets.length > 0
    ? (routingAccuracyCount / allTickets.length) * 100
    : 0;
  
  return {
    totalTickets: allTickets.length,
    openTickets: openTickets.length,
    resolvedTickets: resolvedTickets.length,
    avgConfidence: Number(avgConfidence.toFixed(2)),
    routingAccuracy: Number(routingAccuracy.toFixed(2)),
  };
}
