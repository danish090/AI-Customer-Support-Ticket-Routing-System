import { describe, it, expect, beforeEach } from "vitest";
import * as db from "./db";

describe("Ticket Operations", () => {
  const id = Math.random().toString(36).substring(7);
  
  describe("Ticket Creation", () => {
    it("should create a ticket with valid data", async () => {
      const ticketData = {
        ticketId: `TKT-${id}-1`,
        userId: 1,
        title: "Test Issue",
        description: "This is a test ticket",
        language: "en",
        priority: "medium" as const,
        status: "open" as const,
        aiConfidence: 85.5,
      };

      const result = await db.createTicket(ticketData);
      expect(result).toBeDefined();
    });

    it("should handle ticket with tags", async () => {
      const ticketData = {
        ticketId: `TKT-${id}-2`,
        userId: 1,
        title: "Tagged Issue",
        description: "This ticket has tags",
        language: "en",
        priority: "high" as const,
        status: "open" as const,
        tags: JSON.stringify(["urgent", "critical"]),
      };

      const result = await db.createTicket(ticketData);
      expect(result).toBeDefined();
    });
  });

  describe("Ticket Retrieval", () => {
    it("should retrieve ticket by ID", async () => {
      // Create a ticket first
      const ticketData = {
        ticketId: `TKT-${id}-3`,
        userId: 1,
        title: "Retrieve Test",
        description: "Testing retrieval",
        language: "en",
        priority: "low" as const,
        status: "open" as const,
      };

      await db.createTicket(ticketData);
      const ticket = await db.getTicketByTicketId(`TKT-${id}-3`);
      
      expect(ticket).toBeDefined();
      expect(ticket?.title).toBe("Retrieve Test");
    });
  });

  describe("Ticket Filtering", () => {
    it("should list tickets with filters", async () => {
      // Create test tickets
      const tickets = [
        {
          ticketId: `TKT-${id}-4`,
          userId: 1,
          title: "High Priority Issue",
          description: "Critical problem",
          language: "en",
          priority: "high" as const,
          status: "open" as const,
        },
        {
          ticketId: `TKT-${id}-5`,
          userId: 1,
          title: "Low Priority Issue",
          description: "Minor problem",
          language: "en",
          priority: "low" as const,
          status: "open" as const,
        },
      ];

      for (const ticket of tickets) {
        await db.createTicket(ticket);
      }

      const highPriorityTickets = await db.listTickets({ priority: "high", limit: 10 });
      expect(highPriorityTickets.length).toBeGreaterThan(0);
      expect(highPriorityTickets.some((t: any) => t.priority === "high")).toBe(true);
    });

    it("should search tickets by title", async () => {
      const ticketData = {
        ticketId: `TKT-${id}-6`,
        userId: 1,
        title: "Unique Search Term",
        description: "Testing search functionality",
        language: "en",
        priority: "medium" as const,
        status: "open" as const,
      };

      await db.createTicket(ticketData);
      const results = await db.listTickets({ search: "Unique Search", limit: 10 });
      
      expect(results.length).toBeGreaterThan(0);
    });
  });

  describe("Ticket Updates", () => {
    it("should update ticket status", async () => {
      const ticketData = {
        ticketId: `TKT-${id}-7`,
        userId: 1,
        title: "Update Test",
        description: "Testing updates",
        language: "en",
        priority: "medium" as const,
        status: "open" as const,
      };

      await db.createTicket(ticketData);
      const ticket = await db.getTicketByTicketId(`TKT-${id}-7`);
      
      if (ticket) {
        await db.updateTicket(ticket.id, { status: "in_progress" });
        const updated = await db.getTicketById(ticket.id);
        expect(updated?.status).toBe("in_progress");
      }
    });

    it("should update ticket priority", async () => {
      const ticketData = {
        ticketId: `TKT-${id}-8`,
        userId: 1,
        title: "Priority Test",
        description: "Testing priority update",
        language: "en",
        priority: "low" as const,
        status: "open" as const,
      };

      await db.createTicket(ticketData);
      const ticket = await db.getTicketByTicketId(`TKT-${id}-8`);
      
      if (ticket) {
        await db.updateTicket(ticket.id, { priority: "critical" });
        const updated = await db.getTicketById(ticket.id);
        expect(updated?.priority).toBe("critical");
      }
    });
  });

  describe("Ticket History", () => {
    it("should record ticket history", async () => {
      const ticketData = {
        ticketId: `TKT-${id}-9`,
        userId: 1,
        title: "History Test",
        description: "Testing history tracking",
        language: "en",
        priority: "medium" as const,
        status: "open" as const,
      };

      const result = await db.createTicket(ticketData);
      const ticket = await db.getTicketByTicketId(`TKT-${id}-9`);
      
      if (ticket) {
        await db.addTicketHistory({
          ticketId: ticket.id,
          action: "status_changed",
          previousValue: "open",
          newValue: "in_progress",
        });

        const history = await db.getTicketHistory(ticket.id);
        expect(history.length).toBeGreaterThan(0);
        expect(history[0].action).toBe("status_changed");
      }
    });
  });

  describe("Analytics", () => {
    it("should calculate ticket statistics", async () => {
      const stats = await db.getTicketStats();
      
      expect(stats).toBeDefined();
      expect(stats?.totalTickets).toBeGreaterThanOrEqual(0);
      expect(stats?.openTickets).toBeGreaterThanOrEqual(0);
      expect(stats?.resolvedTickets).toBeGreaterThanOrEqual(0);
      expect(stats?.routingAccuracy).toBeGreaterThanOrEqual(0);
      expect(stats?.routingAccuracy).toBeLessThanOrEqual(100);
    });
  });

  describe("Departments", () => {
    it("should retrieve all departments", async () => {
      const departments = await db.getDepartments();
      
      expect(Array.isArray(departments)).toBe(true);
      expect(departments.length).toBeGreaterThan(0);
    });

    it("should find department by ID", async () => {
      const departments = await db.getDepartments();
      
      if (departments.length > 0) {
        const dept = await db.getDepartmentById(departments[0].id);
        expect(dept).toBeDefined();
        expect(dept?.name).toBe(departments[0].name);
      }
    });
  });
});
