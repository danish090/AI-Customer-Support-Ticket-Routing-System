import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, protectedProcedure, router } from "./_core/trpc";
import { z } from "zod";
import * as db from "./db";
import { nanoid } from "nanoid";
import { invokeLLM } from "./_core/llm";

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  // Departments
  departments: router({
    list: publicProcedure.query(async () => {
      return await db.getDepartments();
    }),
    
    create: protectedProcedure
      .input(z.object({
        name: z.string().min(1),
        description: z.string().optional(),
        icon: z.string().optional(),
        color: z.string().optional(),
      }))
      .mutation(async ({ input }) => {
        return await db.createDepartment(input);
      }),
  }),

  // Tickets
  tickets: router({
    list: publicProcedure
      .input(z.object({
        departmentId: z.number().optional(),
        priority: z.string().optional(),
        status: z.string().optional(),
        search: z.string().optional(),
        limit: z.number().optional().default(20),
        offset: z.number().optional().default(0),
      }))
      .query(async ({ input }) => {
        return await db.listTickets(input);
      }),

    getById: publicProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input }) => {
        const ticket = await db.getTicketById(input.id);
        if (!ticket) return null;
        
        const history = await db.getTicketHistory(input.id);
        const department = ticket.classifiedDepartmentId 
          ? await db.getDepartmentById(ticket.classifiedDepartmentId)
          : null;
        
        return { ticket, history, department };
      }),

    create: protectedProcedure
      .input(z.object({
        title: z.string().min(1),
        description: z.string().min(1),
        language: z.string().default("en"),
        voiceInput: z.boolean().default(false),
        tags: z.array(z.string()).optional(),
      }))
      .mutation(async ({ input, ctx }) => {
        const ticketId = `TKT-${nanoid(8).toUpperCase()}`;
        
        // AI Classification
        const classificationPrompt = `Classify this support ticket:
Title: ${input.title}
Description: ${input.description}

Departments available: Technical Support, Billing, General Inquiry, Bug Report, Feature Request

Respond with JSON: { "department": "department name", "priority": "low|medium|high|critical", "confidence": 0-100 }`;

        let classification = {
          department: "General Inquiry",
          priority: "medium",
          confidence: 50,
        };

        try {
          const response = await invokeLLM({
            messages: [
              {
                role: "system",
                content: "You are a support ticket classifier. Respond only with valid JSON." as any,
              },
              { role: "user", content: classificationPrompt as any },
            ],
            response_format: {
              type: "json_schema",
              json_schema: {
                name: "ticket_classification",
                strict: true,
                schema: {
                  type: "object",
                  properties: {
                    department: { type: "string" },
                    priority: { type: "string", enum: ["low", "medium", "high", "critical"] },
                    confidence: { type: "number", minimum: 0, maximum: 100 },
                  },
                  required: ["department", "priority", "confidence"],
                  additionalProperties: false,
                },
              },
            } as any,
          });

          const content = response.choices[0]?.message.content;
          if (content && typeof content === 'string') {
            const parsed = JSON.parse(content);
            classification = parsed;
          }
        } catch (error) {
          console.error("Classification error:", error);
        }

        // Find department ID
        const departments = await db.getDepartments();
        const matchedDept = departments.find(d => 
          d.name.toLowerCase() === classification.department.toLowerCase()
        );

        const result = await db.createTicket({
          ticketId,
          userId: ctx.user.id,
          title: input.title,
          description: input.description,
          language: input.language,
          voiceInput: input.voiceInput,
          classifiedDepartmentId: matchedDept?.id,
          priority: classification.priority as any,
          aiConfidence: classification.confidence as any,
          status: "open",
          tags: input.tags ? JSON.stringify(input.tags) : null,
        });

        // Get the created ticket ID
        const createdTicket = await db.getTicketByTicketId(ticketId);
        
        if (createdTicket) {
          // Add history entry
          await db.addTicketHistory({
            ticketId: createdTicket.id,
            action: "created",
            newValue: JSON.stringify({
              title: input.title,
              priority: classification.priority,
              department: classification.department,
            }),
          });
        }

        return { ticketId, success: true };
      }),

    update: protectedProcedure
      .input(z.object({
        id: z.number(),
        status: z.enum(["open", "in_progress", "waiting", "resolved", "closed"]).optional(),
        priority: z.enum(["low", "medium", "high", "critical"]).optional(),
        classifiedDepartmentId: z.number().optional(),
        assignedTo: z.number().optional(),
      }))
      .mutation(async ({ input }) => {
        const ticket = await db.getTicketById(input.id);
        if (!ticket) throw new Error("Ticket not found");

        const updates: Record<string, any> = {};
        const historyActions = [];

        if (input.status && input.status !== ticket.status) {
          updates.status = input.status;
          historyActions.push({
            action: "status_changed",
            previousValue: ticket.status,
            newValue: input.status,
          });
        }

        if (input.priority && input.priority !== ticket.priority) {
          updates.priority = input.priority;
          historyActions.push({
            action: "priority_changed",
            previousValue: ticket.priority,
            newValue: input.priority,
          });
        }

        if (input.classifiedDepartmentId && input.classifiedDepartmentId !== ticket.classifiedDepartmentId) {
          updates.classifiedDepartmentId = input.classifiedDepartmentId;
          historyActions.push({
            action: "routed",
            previousValue: ticket.classifiedDepartmentId?.toString(),
            newValue: input.classifiedDepartmentId.toString(),
          });
        }

        if (input.assignedTo && input.assignedTo !== ticket.assignedTo) {
          updates.assignedTo = input.assignedTo;
          historyActions.push({
            action: "assigned",
            newValue: input.assignedTo.toString(),
          });
        }

        if (Object.keys(updates).length > 0) {
          await db.updateTicket(input.id, updates);

          for (const action of historyActions) {
            await db.addTicketHistory({
              ticketId: input.id,
              action: action.action as any,
              previousValue: action.previousValue,
              newValue: action.newValue,
            });
          }
        }

        return { success: true };
      }),

    confirmRouting: protectedProcedure
      .input(z.object({
        id: z.number(),
        accurate: z.boolean(),
      }))
      .mutation(async ({ input }) => {
        await db.updateTicket(input.id, {
          routingAccuracy: input.accurate,
        });

        await db.addTicketHistory({
          ticketId: input.id,
          action: "status_changed",
          newValue: input.accurate ? "Routing confirmed" : "Routing disputed",
        });

        return { success: true };
      }),
  }),

  // Analytics
  analytics: router({
    stats: publicProcedure.query(async () => {
      return await db.getTicketStats();
    }),

    volumeByDepartment: publicProcedure.query(async () => {
      const allTickets = await db.listTickets({ limit: 1000 });
      const departments = await db.getDepartments();
      
      const distribution: Record<string, number> = {};
      departments.forEach((dept: any) => {
        distribution[dept.name] = allTickets.filter((t: any) => t.classifiedDepartmentId === dept.id).length;
      });

      return distribution;
    }),

    priorityDistribution: publicProcedure.query(async () => {
      const allTickets = await db.listTickets({ limit: 1000 });
      
      return {
        low: allTickets.filter((t: any) => t.priority === "low").length,
        medium: allTickets.filter((t: any) => t.priority === "medium").length,
        high: allTickets.filter((t: any) => t.priority === "high").length,
        critical: allTickets.filter((t: any) => t.priority === "critical").length,
      };
    }),

    accuracyTrend: publicProcedure.query(async () => {
      const allTickets = await db.listTickets({ limit: 1000 });
      
      // Group by date
      const byDate: Record<string, any> = {};
      allTickets.forEach((ticket: any) => {
        const date = new Date(ticket.createdAt).toISOString().split('T')[0];
        if (!byDate[date]) {
          byDate[date] = { total: 0, accurate: 0, avgConfidence: 0 };
        }
        byDate[date].total++;
        if (ticket.routingAccuracy) byDate[date].accurate++;
        byDate[date].avgConfidence += Number(ticket.aiConfidence) || 0;
      });

      return Object.entries(byDate).map(([date, data]) => ({
        date,
        accuracy: data.total > 0 ? (data.accurate / data.total) * 100 : 0,
        confidence: data.total > 0 ? data.avgConfidence / data.total : 0,
      }));
    }),
  }),
});

export type AppRouter = typeof appRouter;
